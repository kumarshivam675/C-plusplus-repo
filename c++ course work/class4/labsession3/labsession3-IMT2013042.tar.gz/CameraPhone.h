//Camera.h

#include<string>

//#include "Phone.h"

class Phone;


class CameraPhone: public Phone {
	std::string cameramake;
	int zoomlevel;
	enum photomode{Auto,night, sunny};
public:
	CameraPhone(std::string anum,std::string make);
	void click();
};
