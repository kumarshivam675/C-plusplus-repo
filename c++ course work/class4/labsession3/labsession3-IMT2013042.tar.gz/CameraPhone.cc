//Camera.cc

#include<iostream>
#include<string>
#include "Phone.h"
#include "CameraPhone.h"


CameraPhone::CameraPhone(std::string anum, std::string make) :
	Phone(anum), cameramake(make){
	zoomlevel = 0;	
}  

void CameraPhone::click(){
	std::cout << "Click " << std::endl;
}
